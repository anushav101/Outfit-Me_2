//
//  ParsePhotos.swift
//  Outfit Me_2
//
//  Created by Anusha Venkatesan on 7/19/16.
//  Copyright © 2016 MakeSchool. All rights reserved.
//

import UIKit
import Parse

class ParsePhotos: PFObject, PFSubclassing {
    
    static func parseClassName() -> String {
        return "Product"
    }
    
    
    
}


